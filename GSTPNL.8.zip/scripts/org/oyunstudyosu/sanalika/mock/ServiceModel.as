package org.oyunstudyosu.sanalika.mock
{
   import com.oyunstudyosu.enums.CharacterVariable;
   import com.oyunstudyosu.sanalika.interfaces.IServiceMapping;
   import com.oyunstudyosu.sanalika.interfaces.IServiceVO;
   import com.oyunstudyosu.service.IServiceModel;
   import com.smartfoxserver.v2.SmartFox;
   import com.smartfoxserver.v2.core.SFSEvent;
   import com.smartfoxserver.v2.entities.Room;
   import com.smartfoxserver.v2.entities.SFSRoom;
   import com.smartfoxserver.v2.entities.SFSUser;
   import com.smartfoxserver.v2.entities.data.ISFSObject;
   import com.smartfoxserver.v2.entities.variables.SFSUserVariable;
   import com.smartfoxserver.v2.entities.variables.UserVariable;
   import flash.display.DisplayObjectContainer;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.KeyboardEvent;
   import flash.system.System;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.Dictionary;
   import flash.utils.clearTimeout;
   import flash.utils.getTimer;
   import flash.utils.setTimeout;
   
   public class ServiceModel implements IServiceModel
   {
      
      private var _sfs:SmartFox;
      
      private var list:Dictionary;
      
      private var listenerList:Dictionary;
      
      private var _console:Sprite;
      
      private var _tf:TextField;
      
      private var _uiReady:Boolean = false;
      
      private var _uiVisible:Boolean = true;
      
      private var _uiBuffer:Array = [];
      
      private var _uiMaxLines:int = 12000;
      
      public function ServiceModel()
      {
         var u1:SFSUser;
         var u2:SFSUser;
         var v:UserVariable;
         super();
         this._sfs = new SmartFox(true);
         this._sfs.debug = true;
         try
         {
            this._sfs.enableFullPacketDump(true);
         }
         catch(e0:Error)
         {
         }
         initConsoleWhenReady();
         bindSfsEvents();
         this._sfs.lastJoinedRoom = new SFSRoom(1,"balloonRoom");
         u1 = new SFSUser(1,"emin",true);
         u2 = new SFSUser(2,"önder");
         v = new SFSUserVariable(CharacterVariable.AVATAR_NICK,"Emin");
         u1.setVariables([v]);
         this._sfs.lastJoinedRoom.addUser(u1);
         this.list = new Dictionary();
         this.listenerList = new Dictionary(false);
         hookKeyboardWhenReady();
         logLine("[BOOT] ServiceModel created. Console AUTO-OPEN. (F7 Toggle / F8 Copy / F9 Clear)");
      }
      
      private function initConsoleWhenReady() : void
      {
         try
         {
            if(Sanalika && Sanalika.instance && Sanalika.instance.stage)
            {
               buildConsoleOnRoot();
               return;
            }
         }
         catch(e:Error)
         {
         }
         setTimeout(initConsoleWhenReady,50);
      }
      
      private function hookKeyboardWhenReady() : void
      {
         try
         {
            if(Sanalika && Sanalika.instance && Sanalika.instance.stage)
            {
               Sanalika.instance.stage.addEventListener(KeyboardEvent.KEY_UP,onKeyUp);
               return;
            }
         }
         catch(e:Error)
         {
         }
         setTimeout(hookKeyboardWhenReady,50);
      }
      
      private function getRootContainer() : DisplayObjectContainer
      {
         try
         {
            if(Sanalika && Sanalika.instance)
            {
               if(Sanalika.instance.parent)
               {
                  return Sanalika.instance.parent as DisplayObjectContainer;
               }
               return Sanalika.instance as DisplayObjectContainer;
            }
         }
         catch(e:Error)
         {
         }
         return null;
      }
      
      private function buildConsoleOnRoot() : void
      {
         var st:*;
         var host:DisplayObjectContainer;
         if(_uiReady)
         {
            return;
         }
         st = Sanalika.instance.stage;
         host = getRootContainer();
         if(!host)
         {
            setTimeout(buildConsoleOnRoot,50);
            return;
         }
         _console = new Sprite();
         _console.mouseEnabled = true;
         _console.mouseChildren = true;
         _tf = new TextField();
         _tf.selectable = true;
         _tf.multiline = true;
         _tf.wordWrap = true;
         _tf.background = true;
         _tf.backgroundColor = 0;
         _tf.alpha = 0.95;
         _tf.defaultTextFormat = new TextFormat("_typewriter",12,65280);
         _tf.width = st.stageWidth;
         _tf.height = Math.max(220,int(st.stageHeight * 0.4));
         _tf.x = 0;
         _tf.y = 0;
         _console.addChild(_tf);
         _console.visible = _uiVisible;
         try
         {
            host.addChild(_console);
         }
         catch(e1:Error)
         {
         }
         try
         {
            st.addEventListener(Event.ENTER_FRAME,keepConsoleOnTop);
         }
         catch(e2:Error)
         {
         }
         try
         {
            st.addEventListener(Event.RESIZE,onStageResize);
         }
         catch(e3:Error)
         {
         }
         _uiReady = true;
         flushUi();
         logLine("[UI] Console READY. (Always on top)");
      }
      
      private function keepConsoleOnTop(e:Event) : void
      {
         var host:DisplayObjectContainer;
         if(!_console)
         {
            return;
         }
         host = getRootContainer();
         if(!host)
         {
            return;
         }
         try
         {
            if(_console.parent != host)
            {
               try
               {
                  if(_console.parent)
                  {
                     _console.parent.removeChild(_console);
                  }
               }
               catch(_e0:Error)
               {
               }
               try
               {
                  host.addChild(_console);
               }
               catch(_e1:Error)
               {
               }
            }
         }
         catch(_e2:Error)
         {
         }
         try
         {
            host.setChildIndex(_console,host.numChildren - 1);
         }
         catch(_e3:Error)
         {
         }
      }
      
      private function onStageResize(e:Event) : void
      {
         var st:*;
         try
         {
            st = Sanalika.instance.stage;
            if(_tf)
            {
               _tf.width = st.stageWidth;
               _tf.height = Math.max(220,int(st.stageHeight * 0.4));
            }
         }
         catch(err:Error)
         {
         }
      }
      
      private function ts() : String
      {
         return "[" + getTimer() + "ms]";
      }
      
      private function logLine(s:String) : void
      {
         var line:String = ts() + " " + s;
         _uiBuffer.push(line);
         if(_uiBuffer.length > _uiMaxLines)
         {
            _uiBuffer.shift();
         }
         flushUi();
         try
         {
            trace(line);
         }
         catch(e:Error)
         {
         }
      }
      
      private function logWarn(s:String) : void
      {
         var line:String = ts() + " [WARN] " + s;
         _uiBuffer.push(line);
         if(_uiBuffer.length > _uiMaxLines)
         {
            _uiBuffer.shift();
         }
         flushUi();
         try
         {
            trace(line);
         }
         catch(e:Error)
         {
         }
      }
      
      private function flushUi() : void
      {
         if(!_uiReady || !_tf)
         {
            return;
         }
         var maxView:int = 900;
         var start:int = Math.max(0,_uiBuffer.length - maxView);
         _tf.text = _uiBuffer.slice(start).join("\n");
         _tf.scrollV = _tf.maxScrollV;
      }
      
      private function dumpObj(o:*) : String
      {
         try
         {
            return JSON.stringify(o);
         }
         catch(e:Error)
         {
         }
         try
         {
            return String(o);
         }
         catch(e2:Error)
         {
         }
         return "[unprintable]";
      }
      
      protected function onKeyUp(e:KeyboardEvent) : void
      {
         var o:Object;
         if(e.keyCode == 118)
         {
            _uiVisible = !_uiVisible;
            if(_console)
            {
               _console.visible = _uiVisible;
            }
            logLine("[UI] Toggle console (F7) visible=" + _uiVisible);
            return;
         }
         if(e.keyCode == 119)
         {
            try
            {
               System.setClipboard(_uiBuffer.join("\n"));
            }
            catch(ex:Error)
            {
            }
            logLine("[UI] Copy logs (F8) lines=" + _uiBuffer.length);
            return;
         }
         if(e.keyCode == 120)
         {
            _uiBuffer.length = 0;
            if(_tf)
            {
               _tf.text = "";
            }
            logLine("[UI] Clear logs (F9)");
            return;
         }
         o = Sanalika.panelManager.popupMockHandler.dispatchExtension(e.keyCode);
         if(o && o.key && Boolean(o.params))
         {
            logLine("[C->S][MOCK_KEY] key=" + o.key + " params=" + dumpObj(o.params));
            try
            {
               this.listenerList[o.key](o.params);
            }
            catch(err:Error)
            {
               logWarn("[MOCK_KEY_HANDLER_ERR] " + err.message);
            }
         }
      }
      
      private function bindSfsEvents() : void
      {
         this._sfs.addEventListener(SFSEvent.CONNECTION,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.CONNECTION_LOST,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.CONNECTION_RETRY,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.CONNECTION_RESUME,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.HANDSHAKE,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.LOGIN,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.LOGIN_ERROR,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.ROOM_JOIN,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.ROOM_JOIN_ERROR,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.EXTENSION_RESPONSE,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.EXTENSION_RESPONSE_ERROR,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.USER_VARIABLES_UPDATE,onSfsEvent);
         this._sfs.addEventListener(SFSEvent.ROOM_VARIABLES_UPDATE,onSfsEvent);
      }
      
      private function onSfsEvent(e:SFSEvent) : void
      {
         var p:Object = e.params;
         var extra:String = "";
         try
         {
            if(p && p.hasOwnProperty("cmd"))
            {
               extra += " cmd=" + p["cmd"];
            }
         }
         catch(_e1:Error)
         {
         }
         try
         {
            if(p && p.hasOwnProperty("errorMessage"))
            {
               extra += " err=" + p["errorMessage"];
            }
         }
         catch(_e2:Error)
         {
         }
         try
         {
            if(p && p.hasOwnProperty("params"))
            {
               if(p["params"] is ISFSObject)
               {
                  extra += " paramsDump=" + ISFSObject(p["params"]).getDump();
               }
               else
               {
                  extra += " params=" + dumpObj(p["params"]);
               }
            }
         }
         catch(_e3:Error)
         {
         }
         try
         {
            if(p && p.hasOwnProperty("data"))
            {
               extra += " data=" + dumpObj(p["data"]);
            }
         }
         catch(_e4:Error)
         {
         }
         logLine("[S->C][EVENT] " + e.type + extra);
      }
      
      public function get sfs() : SmartFox
      {
         return this._sfs;
      }
      
      public function set sfs(v:SmartFox) : void
      {
         this._sfs = v;
      }
      
      public function activate() : void
      {
      }
      
      public function deactivate() : void
      {
      }
      
      public function remove(vo:IServiceVO, dispose:Boolean = true) : void
      {
      }
      
      public function removeByKey(key:String, dispose:Boolean = true) : void
      {
      }
      
      public function listenRoomVariable(key:String, fn:Function) : void
      {
         this.listenerList[key] = fn;
      }
      
      public function listenUserVariable(key:String, fn:Function) : void
      {
         this.listenerList[key] = fn;
      }
      
      public function listenExtension(key:String, fn:Function) : void
      {
         this.listenerList[key] = fn;
      }
      
      public function requestExtension(key:String, data:Object, cb:Function, room:Room = null) : void
      {
         logLine("[C->S][requestExtension] key=" + key + " data=" + dumpObj(data) + " room=" + (room ? room.name : "null"));
         var r:Object = Sanalika.panelManager.popupMockHandler.requestData(key,data);
         if(r)
         {
            logLine("[S->C][MOCK_RESPONSE] key=" + key + " data=" + dumpObj(r["data"]));
            this.list[key] = setTimeout(cb,100,r["data"]);
         }
         else
         {
            logWarn("[S->C][MOCK_RESPONSE_MISSING] key=" + key);
         }
      }
      
      public function requestData(key:String, data:Object, cb:Function, room:Room = null) : void
      {
         logLine("[C->S][requestData] key=" + key + " data=" + dumpObj(data) + " room=" + (room ? room.name : "null"));
         var r:Object = Sanalika.panelManager.popupMockHandler.requestData(key,data);
         if(r)
         {
            logLine("[S->C][MOCK_RESPONSE] key=" + key + " data=" + dumpObj(r["data"]));
            this.list[key] = setTimeout(cb,100,r["data"]);
         }
         else
         {
            logWarn("[S->C][MOCK_RESPONSE_MISSING] key=" + key);
         }
      }
      
      public function removeRequestData(key:String, cb:Function) : void
      {
         clearTimeout(this.list[key]);
      }
      
      public function removeRequestExtension(key:String, cb:Function) : void
      {
         clearTimeout(this.list[key]);
      }
      
      public function setRoomVariable(a:Array, b:Array) : void
      {
      }
      
      public function setUserVariable(a:Array, b:Array) : void
      {
      }
      
      public function removeExtension(key:String, fn:Function) : void
      {
      }
      
      public function removeUserVariable(key:String, fn:Function) : void
      {
      }
      
      public function removeRoomVariable(key:String, fn:Function) : void
      {
      }
      
      public function get map() : IServiceMapping
      {
         return null;
      }
   }
}

