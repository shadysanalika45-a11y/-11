package org.oyunstudyosu.sanalika.panels.august
{
   import com.oyunstudyosu.sanalika.mock.IExtensionMock;
   
   public class AugustPanelSecondMock implements IExtensionMock
   {
      
      public function AugustPanelSecondMock()
      {
         super();
      }
      
      public function requestData(param1:String, param2:Object) : Object
      {
         return null;
      }
      
      public function getInitData() : Object
      {
         return null;
      }
      
      public function dispatchExtension(param1:uint) : Object
      {
         return null;
      }
   }
}

