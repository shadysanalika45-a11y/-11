package com.smartfoxserver.v2.logging
{
   import flash.utils.Dictionary;
   import flash.utils.getTimer;
   
   public class NetTrace
   {
      
      public static var enabled:Boolean = true;
      
      private static var _seq:uint = 0;
      
      private static var _pending:Dictionary = new Dictionary();
      
      public function NetTrace()
      {
         super();
      }
      
      public static function nextSeq() : uint
      {
         var _loc1_:* = §§findproperty(_seq);
         var _loc2_:* = Number(_loc1_._seq) + 1;
         _loc1_._seq = _loc2_;
         return _seq;
      }
      
      public static function markPending(seq:uint, kind:String, info:String) : void
      {
         _pending[seq] = {
            "t":getTimer(),
            "kind":kind,
            "info":info
         };
      }
      
      public static function clearPendingBySeq(seq:uint) : void
      {
         delete _pending[seq];
      }
      
      public static function getPendingSnapshot(maxAgeMs:int = 5000) : Array
      {
         var now:int = getTimer();
         var out:Array = [];
         for(var k in _pending)
         {
            var o:Object = _pending[k];
            if(now - int(o.t) >= maxAgeMs)
            {
               out.push({
                  "seq":uint(k),
                  "age":now - int(o.t),
                  "kind":o.kind,
                  "info":o.info
               });
            }
         }
         return out;
      }
      
      public static function ts() : String
      {
         return "[" + getTimer() + "ms]";
      }
   }
}

