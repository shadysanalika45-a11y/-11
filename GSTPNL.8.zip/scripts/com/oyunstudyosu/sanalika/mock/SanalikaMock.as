package com.oyunstudyosu.sanalika.mock
{
   import com.oyunstudyosu.alert.IAlertModel;
   import com.oyunstudyosu.assets.AssetModel;
   import com.oyunstudyosu.assets.IAssetModel;
   import com.oyunstudyosu.chat.IChatModel;
   import com.oyunstudyosu.cloth.IClothModel;
   import com.oyunstudyosu.data.DataModel;
   import com.oyunstudyosu.data.IDataModel;
   import com.oyunstudyosu.displayAd.IAdModel;
   import com.oyunstudyosu.events.Dispatcher;
   import com.oyunstudyosu.local.ILocalizationModel;
   import com.oyunstudyosu.local.LocalizationModel;
   import com.oyunstudyosu.model.AirModel;
   import com.oyunstudyosu.quest.IQuestModel;
   import com.oyunstudyosu.sanalika.interfaces.IAirModel;
   import com.oyunstudyosu.sanalika.interfaces.IAvatarModel;
   import com.oyunstudyosu.sanalika.interfaces.IBuddyModel;
   import com.oyunstudyosu.sanalika.interfaces.ICookieModel;
   import com.oyunstudyosu.sanalika.interfaces.IGameModel;
   import com.oyunstudyosu.sanalika.interfaces.IItemModel;
   import com.oyunstudyosu.sanalika.interfaces.ILayerModel;
   import com.oyunstudyosu.sanalika.interfaces.IModuleModel;
   import com.oyunstudyosu.sanalika.interfaces.IPanelModel;
   import com.oyunstudyosu.sanalika.interfaces.IRoomModel;
   import com.oyunstudyosu.sanalika.interfaces.IToolTipModel;
   import com.oyunstudyosu.sanalika.interfaces.update.IUpdateModel;
   import com.oyunstudyosu.sanalika.sound.SoundKey;
   import com.oyunstudyosu.service.IServiceModel;
   import com.oyunstudyosu.sound.ISoundModel;
   import com.oyunstudyosu.sound.SoundModel;
   import flash.display.Sprite;
   import flash.display.StageAlign;
   import flash.display.StageScaleMode;
   import flash.events.Event;
   import flash.events.KeyboardEvent;
   import flash.events.MouseEvent;
   import flash.events.UncaughtErrorEvent;
   import flash.system.ApplicationDomain;
   import flash.system.System;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.text.TextFormat;
   import flash.utils.getTimer;
   
   public class SanalikaMock extends Sprite
   {
      
      private static var _consoleReady:Boolean = false;
      
      private static var _consoleVisible:Boolean = true;
      
      private static var _buf:Array = [];
      
      private static var _maxLines:int = 12000;
      
      public var airModel:IAirModel;
      
      public var configModel:Object;
      
      public var assetModel:IAssetModel;
      
      public var gameModel:IGameModel;
      
      public var roomModel:IRoomModel;
      
      public var avatarModel:IAvatarModel;
      
      public var layerModel:ILayerModel;
      
      public var panelModel:IPanelModel;
      
      public var itemModel:IItemModel;
      
      public var clothModel:IClothModel;
      
      public var serviceModel:IServiceModel;
      
      public var buddyModel:IBuddyModel;
      
      public var chatModel:IChatModel;
      
      public var toolTipModel:IToolTipModel;
      
      public var localizationModel:ILocalizationModel;
      
      public var alertModel:IAlertModel;
      
      public var dataModel:IDataModel;
      
      public var moduleModel:IModuleModel;
      
      public var soundModel:ISoundModel;
      
      public var domainModel:MockDomainModel;
      
      public var updateModel:IUpdateModel;
      
      public var adModel:IAdModel;
      
      public var cookieModel:ICookieModel;
      
      public var questModel:IQuestModel;
      
      private var _console:Sprite;
      
      private var _tf:TextField;
      
      private var _btnCopy:Sprite;
      
      private var _btnClear:Sprite;
      
      private var _btnHide:Sprite;
      
      public function SanalikaMock()
      {
         super();
         this.addEventListener(Event.ADDED_TO_STAGE,this.onAddedStage);
      }
      
      public static function log(s:String) : void
      {
         var line:String = "[" + getTimer() + "ms] " + s;
         _buf.push(line);
         if(_buf.length > _maxLines)
         {
            _buf.shift();
         }
         try
         {
            trace(line);
         }
         catch(e:Error)
         {
         }
      }
      
      private function initConsole() : void
      {
         if(_consoleReady)
         {
            return;
         }
         _console = new Sprite();
         _console.mouseEnabled = true;
         _console.mouseChildren = true;
         _tf = new TextField();
         _tf.selectable = true;
         _tf.multiline = true;
         _tf.wordWrap = true;
         _tf.background = true;
         _tf.backgroundColor = 0;
         _tf.alpha = 0.92;
         _tf.defaultTextFormat = new TextFormat("_typewriter",12,65280);
         _console.addChild(_tf);
         _btnCopy = makeBtn("COPY (F8)");
         _btnClear = makeBtn("CLEAR (F9)");
         _btnHide = makeBtn("HIDE (F7)");
         _btnCopy.addEventListener(MouseEvent.CLICK,onCopy);
         _btnClear.addEventListener(MouseEvent.CLICK,onClear);
         _btnHide.addEventListener(MouseEvent.CLICK,onToggle);
         _console.addChild(_btnCopy);
         _console.addChild(_btnClear);
         _console.addChild(_btnHide);
         addChild(_console);
         _console.visible = _consoleVisible;
         stage.addEventListener(Event.RESIZE,onResize);
         stage.addEventListener(Event.ENTER_FRAME,keepOnTop);
         stage.addEventListener(KeyboardEvent.KEY_UP,onKeyUpGlobal);
         try
         {
            if(stage.loaderInfo && stage.loaderInfo.uncaughtErrorEvents)
            {
               stage.loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR,onUncaught);
            }
         }
         catch(e:Error)
         {
         }
         onResize(null);
         _consoleReady = true;
         log("[UI] Console READY + AUTO OPEN");
         redraw();
      }
      
      private function makeBtn(label:String) : Sprite
      {
         var sp:Sprite = new Sprite();
         sp.graphics.beginFill(2236962,0.9);
         sp.graphics.drawRoundRect(0,0,95,20,6,6);
         sp.graphics.endFill();
         var t:TextField = new TextField();
         t.selectable = false;
         t.mouseEnabled = false;
         t.defaultTextFormat = new TextFormat("_sans",11,16777215,true);
         t.autoSize = TextFieldAutoSize.LEFT;
         t.text = label;
         t.x = 6;
         t.y = 2;
         sp.addChild(t);
         sp.buttonMode = true;
         sp.useHandCursor = true;
         return sp;
      }
      
      private function onResize(e:Event) : void
      {
         if(!stage || !_tf)
         {
            return;
         }
         _tf.x = 0;
         _tf.y = 0;
         _tf.width = stage.stageWidth;
         _tf.height = Math.max(240,int(stage.stageHeight * 0.4));
         var pad:int = 6;
         _btnHide.y = pad;
         _btnClear.y = pad;
         _btnCopy.y = pad;
         _btnHide.x = stage.stageWidth - _btnHide.width - pad;
         _btnClear.x = _btnHide.x - _btnClear.width - pad;
         _btnCopy.x = _btnClear.x - _btnCopy.width - pad;
      }
      
      private function keepOnTop(e:Event) : void
      {
         try
         {
            if(_console && _console.parent == this)
            {
               setChildIndex(_console,numChildren - 1);
            }
         }
         catch(err:Error)
         {
         }
      }
      
      private function onKeyUpGlobal(e:KeyboardEvent) : void
      {
         if(e.keyCode == 118)
         {
            onToggle(null);
            return;
         }
         if(e.keyCode == 119)
         {
            onCopy(null);
            return;
         }
         if(e.keyCode == 120)
         {
            onClear(null);
            return;
         }
      }
      
      private function onToggle(e:Event) : void
      {
         _consoleVisible = !_consoleVisible;
         if(_console)
         {
            _console.visible = _consoleVisible;
         }
         log("[UI] Toggle console visible=" + _consoleVisible);
         redraw();
      }
      
      private function onCopy(e:Event) : void
      {
         try
         {
            System.setClipboard(_buf.join("\n"));
         }
         catch(err:Error)
         {
         }
         log("[UI] Copied logs lines=" + _buf.length);
         redraw();
      }
      
      private function onClear(e:Event) : void
      {
         _buf.length = 0;
         if(_tf)
         {
            _tf.text = "";
         }
         log("[UI] Cleared logs");
         redraw();
      }
      
      private function onUncaught(e:UncaughtErrorEvent) : void
      {
         try
         {
            log("[UNCAUGHT] " + String(e.error));
         }
         catch(err:Error)
         {
            log("[UNCAUGHT] <unknown>");
         }
         redraw();
      }
      
      private function redraw() : void
      {
         if(!_consoleReady || !_tf)
         {
            return;
         }
         var maxView:int = 900;
         var start:int = Math.max(0,_buf.length - maxView);
         _tf.text = _buf.slice(start).join("\n");
         _tf.scrollV = _tf.maxScrollV;
      }
      
      protected function onAddedStage(param1:Event) : void
      {
         this.stage.scaleMode = StageScaleMode.NO_SCALE;
         this.stage.align = StageAlign.TOP_LEFT;
         initConsole();
         log("[BOOT] SanalikaMock added to stage. Console AUTO OPEN.");
         this.domainModel = new MockDomainModel();
         this.domainModel.checkPolicyFile = false;
         this.domainModel.securityDomain = null;
         this.domainModel.mainAppDomain = ApplicationDomain.currentDomain;
         this.domainModel.subAppDomain = new ApplicationDomain(ApplicationDomain.currentDomain);
         this.gameModel = new GameModel();
         this.assetModel = new AssetModel(stage);
         this.layerModel = new LayerModel(stage);
         this.itemModel = new ItemModel();
         this.avatarModel = new AvatarModel();
         this.clothModel = new ClothModel();
         this.roomModel = new RoomModel();
         this.chatModel = new ChatModel();
         this.buddyModel = new BuddyModel();
         this.alertModel = new AlertModel();
         this.dataModel = new DataModel();
         this.soundModel = new SoundModel();
         this.moduleModel = new ModuleModel();
         this.adModel = new DummyAdModel();
         this.airModel = new AirModel(stage);
         this.soundModel.addSound(SoundKey.BUTTON_CLICK,"../../sanalika-debug/static/sounds/click.mp3");
         this.localizationModel = new LocalizationModel();
         Dispatcher.addEventListener(LocalizationModel.LOCALIZATION_DATA_READY,this.onComplete);
         var _loc2_:Object = {};
         _loc2_.stage = this.layerModel.stage;
         _loc2_.toolTipModel = this.toolTipModel;
         _loc2_.language = this.gameModel.language;
         _loc2_.fileServer = this.gameModel.fileServer;
         _loc2_.version = this.gameModel.languageFileVersion;
         _loc2_.debugMode = true;
         this.localizationModel.init(_loc2_);
         redraw();
      }
      
      public function onComplete(param1:Event) : void
      {
         log("[LOCALIZATION] Data ready");
         redraw();
      }
   }
}

