package com.worlize.websocket
{
   import com.adobe.net.URI;
   import com.adobe.net.URIEncodingBitmap;
   import com.adobe.utils.StringUtil;
   import com.hurlant.crypto.hash.SHA1;
   import com.hurlant.util.Base64;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.IOErrorEvent;
   import flash.events.ProgressEvent;
   import flash.events.SecurityErrorEvent;
   import flash.events.TimerEvent;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.Endian;
   import flash.utils.Timer;
   
   public class WebSocket extends EventDispatcher
   {
      
      private static const MODE_UTF8:int = 0;
      
      private static const MODE_BINARY:int = 0;
      
      private static const MAX_HANDSHAKE_BYTES:int = 10 * 1024;
      
      public static function logger(param1:String):void
      {
         trace(param1);
      }
      private var _bufferedAmount:int = 0;
      
      private var _readyState:int;
      
      private var _uri:URI;
      
      private var _protocols:Array;
      
      private var _serverProtocol:String;
      
      private var _host:String;
      
      private var _port:uint;
      
      private var _resource:String;
      
      private var _secure:Boolean;
      
      private var _origin:String;
      
      private var _useNullMask:Boolean = false;
      
      private var rawSocket:Socket;
      
      private var socket:Socket;
      
      private var timeout:uint;
      
      private var fatalError:Boolean = false;
      
      private var nonce:ByteArray;
      
      private var base64nonce:String;
      
      private var serverHandshakeResponse:String;
      
      private var serverExtensions:Array;
      
      private var currentFrame:WebSocketFrame;
      
      private var frameQueue:Vector.<WebSocketFrame>;
      
      private var fragmentationOpcode:int = 0;
      
      private var fragmentationSize:uint = 0;
      
      private var waitingForServerClose:Boolean = false;
      
      private var closeTimeout:int = 5000;
      
      private var closeTimer:Timer;
      
      private var handshakeBytesReceived:int;
      
      private var handshakeTimer:Timer;
      
      private var handshakeTimeout:int = 10000;
      
      private var URIpathExcludedBitmap:URIEncodingBitmap;
      
      public var config:WebSocketConfig;
      
      public var debug:Boolean = false;
      
      public function WebSocket(param1:String, param2:String, param3:* = null, param4:uint = 10000)
      {
         var _loc5_:int = 0;
         this.URIpathExcludedBitmap = new URIEncodingBitmap(URI.URIpathEscape);
         this.config = new WebSocketConfig();
         super(null);
         this._uri = new URI(param1);
         if(param3 is String)
         {
            this._protocols = [param3];
         }
         else
         {
            this._protocols = param3;
         }
         if(this._protocols)
         {
            _loc5_ = 0;
            while(_loc5_ < this._protocols.length)
            {
               this._protocols[_loc5_] = StringUtil.trim(this._protocols[_loc5_]);
               _loc5_++;
            }
         }
         this._origin = param2;
         this.timeout = param4;
         this.handshakeTimeout = param4;
         this.init();
      }
      
      private function init() : void
      {
         this.parseUrl();
         this.validateProtocol();
         this.frameQueue = new Vector.<WebSocketFrame>();
         this.fragmentationOpcode = 0;
         this.fragmentationSize = 0;
         this.currentFrame = new WebSocketFrame();
         this.fatalError = false;
         this.closeTimer = new Timer(this.closeTimeout,1);
         this.closeTimer.addEventListener(TimerEvent.TIMER,this.handleCloseTimer);
         this.handshakeTimer = new Timer(this.handshakeTimeout,1);
         this.handshakeTimer.addEventListener(TimerEvent.TIMER,this.handleHandshakeTimer);
         this.rawSocket = this.socket = new Socket();
         this.socket.timeout = this.timeout;
         this.rawSocket.addEventListener(Event.CONNECT,this.handleSocketConnect);
         this.rawSocket.addEventListener(IOErrorEvent.IO_ERROR,this.handleSocketIOError);
         this.rawSocket.addEventListener(SecurityErrorEvent.SECURITY_ERROR,this.handleSocketSecurityError);
         this.socket.addEventListener(Event.CLOSE,this.handleSocketClose);
         this.socket.addEventListener(ProgressEvent.SOCKET_DATA,this.handleSocketData);
         this._readyState = WebSocketState.INIT;
      }
      
      private function validateProtocol() : void
      {
         var _loc1_:Array = null;
         var _loc2_:int = 0;
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:String = null;
         if(this._protocols)
         {
            _loc1_ = ["(",")","<",">","@",",",";",":","\\","\"","/","[","]","?","=","{","}"," ",String.fromCharCode(9)];
            _loc2_ = 0;
            while(_loc2_ < this._protocols.length)
            {
               _loc3_ = this._protocols[_loc2_];
               _loc4_ = 0;
               while(_loc4_ < _loc3_.length)
               {
                  _loc5_ = int(_loc3_.charCodeAt(_loc4_));
                  _loc6_ = _loc3_.charAt(_loc4_);
                  if(_loc5_ < 33 || _loc5_ > 126 || _loc1_.indexOf(_loc6_) !== -1)
                  {
                     throw new WebSocketError("Illegal character \'" + String.fromCharCode(_loc6_) + "\' in subprotocol.");
                  }
                  _loc4_++;
               }
               _loc2_++;
            }
         }
      }
      
      public function connect() : void
      {
         if(this._readyState === WebSocketState.INIT || this._readyState === WebSocketState.CLOSED)
         {
            this._readyState = WebSocketState.CONNECTING;
            this.generateNonce();
            this.handshakeBytesReceived = 0;
            this.rawSocket.connect(this._host,this._port);
            if(this.debug)
            {
               logger("Connecting to " + this._host + " on port " + this._port);
            }
         }
      }
      
      private function parseUrl() : void
      {
         this._host = this._uri.authority;
         var _loc1_:String = this._uri.scheme.toLocaleLowerCase();
         switch(_loc1_)
         {
            case "wss":
               this._secure = true;
               this._port = 443;
               break;
            case "ws":
               this._secure = false;
               this._port = 80;
               break;
            default:
               throw new Error("Unsupported scheme: " + _loc1_);
         }
         var _loc2_:uint = parseInt(this._uri.port,10);
         if(!isNaN(_loc2_) && _loc2_ !== 0)
         {
            this._port = _loc2_;
         }
         var _loc3_:String = URI.fastEscapeChars(this._uri.path,this.URIpathExcludedBitmap);
         if(_loc3_.length === 0)
         {
            _loc3_ = "/";
         }
         var _loc4_:String = this._uri.queryRaw;
         if(_loc4_.length > 0)
         {
            _loc4_ = "?" + _loc4_;
         }
         this._resource = _loc3_ + _loc4_;
      }
      
      private function generateNonce() : void
      {
         this.nonce = new ByteArray();
         var _loc1_:int = 0;
         while(_loc1_ < 16)
         {
            this.nonce.writeByte(Math.round(Math.random() * 255));
            _loc1_++;
         }
         this.nonce.position = 0;
         this.base64nonce = Base64.encodeByteArray(this.nonce);
      }
      
      public function get readyState() : int
      {
         return this._readyState;
      }
      
      public function get bufferedAmount() : int
      {
         return this._bufferedAmount;
      }
      
      public function get uri() : String
      {
         var _loc1_:String = null;
         _loc1_ = this._secure ? "wss://" : "ws://";
         _loc1_ += this._host;
         if(this._secure && this._port !== 443 || !this._secure && this._port !== 80)
         {
            _loc1_ += ":" + this._port.toString();
         }
         return _loc1_ + this._resource;
      }
      
      public function get protocol() : String
      {
         return this._serverProtocol;
      }
      
      public function get extensions() : Array
      {
         return [];
      }
      
      public function get host() : String
      {
         return this._host;
      }
      
      public function get port() : uint
      {
         return this._port;
      }
      
      public function get resource() : String
      {
         return this._resource;
      }
      
      public function get secure() : Boolean
      {
         return this._secure;
      }
      
      public function get connected() : Boolean
      {
         return this.readyState === WebSocketState.OPEN;
      }
      
      public function set useNullMask(param1:Boolean) : void
      {
         this._useNullMask = param1;
      }
      
      public function get useNullMask() : Boolean
      {
         return this._useNullMask;
      }
      
      private function verifyConnectionForSend() : void
      {
         if(this._readyState === WebSocketState.CONNECTING)
         {
            throw new WebSocketError("Invalid State: Cannot send data before connected.");
         }
      }
      
      public function sendUTF(param1:String) : void
      {
         this.verifyConnectionForSend();
         var _loc2_:WebSocketFrame = new WebSocketFrame();
         _loc2_.opcode = WebSocketOpcode.TEXT_FRAME;
         _loc2_.binaryPayload = new ByteArray();
         _loc2_.binaryPayload.writeMultiByte(param1,"utf-8");
         this.fragmentAndSend(_loc2_);
      }
      
      public function sendBytes(param1:ByteArray) : void
      {
         this.verifyConnectionForSend();
         var _loc2_:WebSocketFrame = new WebSocketFrame();
         _loc2_.opcode = WebSocketOpcode.BINARY_FRAME;
         _loc2_.binaryPayload = param1;
         this.fragmentAndSend(_loc2_);
      }
      
      public function ping(param1:ByteArray = null) : void
      {
         this.verifyConnectionForSend();
         var _loc2_:WebSocketFrame = new WebSocketFrame();
         _loc2_.fin = true;
         _loc2_.opcode = WebSocketOpcode.PING;
         if(param1)
         {
            _loc2_.binaryPayload = param1;
         }
         this.sendFrame(_loc2_);
      }
      
      private function pong(param1:ByteArray = null) : void
      {
         this.verifyConnectionForSend();
         var _loc2_:WebSocketFrame = new WebSocketFrame();
         _loc2_.fin = true;
         _loc2_.opcode = WebSocketOpcode.PONG;
         _loc2_.binaryPayload = param1;
         this.sendFrame(_loc2_);
      }
      
      private function fragmentAndSend(param1:WebSocketFrame) : void
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:WebSocketFrame = null;
         var _loc7_:int = 0;
         if(param1.opcode > 7)
         {
            throw new WebSocketError("You cannot fragment control frames.");
         }
         var _loc2_:uint = this.config.fragmentationThreshold;
         if(this.config.fragmentOutgoingMessages && param1.binaryPayload && param1.binaryPayload.length > _loc2_)
         {
            param1.binaryPayload.position = 0;
            _loc3_ = int(param1.binaryPayload.length);
            _loc4_ = Math.ceil(_loc3_ / _loc2_);
            _loc5_ = 1;
            while(_loc5_ <= _loc4_)
            {
               _loc6_ = new WebSocketFrame();
               _loc6_.opcode = _loc5_ === 1 ? param1.opcode : 0;
               _loc6_.fin = _loc5_ === _loc4_;
               _loc7_ = _loc5_ === _loc4_ ? int(_loc3_ - _loc2_ * (_loc5_ - 1)) : int(_loc2_);
               param1.binaryPayload.position = _loc2_ * (_loc5_ - 1);
               _loc6_.binaryPayload = new ByteArray();
               param1.binaryPayload.readBytes(_loc6_.binaryPayload,0,_loc7_);
               this.sendFrame(_loc6_);
               _loc5_++;
            }
         }
         else
         {
            param1.fin = true;
            this.sendFrame(param1);
         }
      }
      
      private function sendFrame(param1:WebSocketFrame, param2:Boolean = false) : void
      {
         param1.mask = true;
         param1.useNullMask = this._useNullMask;
         var _loc3_:ByteArray = new ByteArray();
         param1.send(_loc3_);
         this.sendData(_loc3_);
      }
      
      private function sendData(param1:ByteArray, param2:Boolean = false) : void
      {
         if(!this.connected)
         {
            return;
         }
         param1.position = 0;
         this.socket.writeBytes(param1,0,param1.bytesAvailable);
         this.socket.flush();
         param1.clear();
      }
      
      public function close(param1:Boolean = true) : void
      {
         var _loc2_:WebSocketFrame = null;
         var _loc3_:ByteArray = null;
         if(!this.socket.connected && this._readyState === WebSocketState.CONNECTING)
         {
            this._readyState = WebSocketState.CLOSED;
            try
            {
               this.socket.close();
            }
            catch(e:Error)
            {
            }
         }
         if(this.socket.connected)
         {
            _loc2_ = new WebSocketFrame();
            _loc2_.rsv1 = _loc2_.rsv2 = _loc2_.rsv3 = _loc2_.mask = false;
            _loc2_.fin = true;
            _loc2_.opcode = WebSocketOpcode.CONNECTION_CLOSE;
            _loc2_.closeStatus = WebSocketCloseStatus.NORMAL;
            _loc3_ = new ByteArray();
            _loc2_.mask = true;
            _loc2_.send(_loc3_);
            this.sendData(_loc3_,true);
            if(param1)
            {
               this.waitingForServerClose = true;
               this.closeTimer.stop();
               this.closeTimer.reset();
               this.closeTimer.start();
            }
            this.dispatchClosedEvent();
         }
      }
      
      private function handleCloseTimer(param1:TimerEvent) : void
      {
         if(this.waitingForServerClose)
         {
            if(this.socket.connected)
            {
               this.socket.close();
            }
         }
      }
      
      private function handleSocketConnect(param1:Event) : void
      {
         if(this.debug)
         {
            logger("Socket Connected");
         }
         if(this.secure)
         {
            if(this.debug)
            {
               logger("starting SSL/TLS");
            }
         }
         this.socket.endian = Endian.BIG_ENDIAN;
         this.sendHandshake();
      }
      
      private function handleSocketClose(param1:Event) : void
      {
         if(this.debug)
         {
            logger("Socket Disconnected");
         }
         this.dispatchClosedEvent();
      }
      
      private function handleSocketData(param1:ProgressEvent = null) : void
      {
         var _loc2_:WebSocketEvent = null;
         if(this._readyState === WebSocketState.CONNECTING)
         {
            this.readServerHandshake();
            return;
         }
         while(this.socket.connected && this.currentFrame.addData(this.socket,this.fragmentationOpcode,this.config) && !this.fatalError)
         {
            if(this.currentFrame.protocolError)
            {
               this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,this.currentFrame.dropReason);
               trace("PROTOCOL_ERROR");
               return;
            }
            if(this.currentFrame.frameTooLarge)
            {
               this.drop(WebSocketCloseStatus.MESSAGE_TOO_LARGE,this.currentFrame.dropReason);
               trace("MESSAGE_TOO_LARGE");
               return;
            }
            if(!this.config.assembleFragments)
            {
               _loc2_ = new WebSocketEvent(WebSocketEvent.FRAME);
               _loc2_.frame = this.currentFrame;
               dispatchEvent(_loc2_);
            }
            this.processFrame(this.currentFrame);
            this.currentFrame = new WebSocketFrame();
         }
      }
      
      private function processFrame(param1:WebSocketFrame) : void
      {
         var _loc2_:WebSocketEvent = null;
         var _loc3_:int = 0;
         var _loc4_:WebSocketFrame = null;
         var _loc5_:WebSocketEvent = null;
         var _loc6_:WebSocketEvent = null;
         var _loc7_:int = 0;
         var _loc8_:ByteArray = null;
         var _loc9_:int = 0;
         if(param1.rsv1 || param1.rsv2 || param1.rsv3)
         {
            this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Received frame with reserved bit set without a negotiated extension.");
            return;
         }
         switch(param1.opcode)
         {
            case WebSocketOpcode.BINARY_FRAME:
               if(this.config.assembleFragments)
               {
                  if(this.frameQueue.length === 0)
                  {
                     if(param1.fin)
                     {
                        _loc2_ = new WebSocketEvent(WebSocketEvent.MESSAGE);
                        _loc2_.message = new WebSocketMessage();
                        _loc2_.message.type = WebSocketMessage.TYPE_BINARY;
                        _loc2_.message.binaryData = param1.binaryPayload;
                        dispatchEvent(_loc2_);
                        break;
                     }
                     if(this.frameQueue.length === 0)
                     {
                        this.frameQueue.push(param1);
                        this.fragmentationOpcode = param1.opcode;
                     }
                     break;
                  }
                  this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Illegal BINARY_FRAME received in the middle of a fragmented message.  Expected a continuation or control frame.");
                  return;
               }
               break;
            case WebSocketOpcode.TEXT_FRAME:
               if(this.config.assembleFragments)
               {
                  if(this.frameQueue.length === 0)
                  {
                     if(param1.fin)
                     {
                        _loc2_ = new WebSocketEvent(WebSocketEvent.MESSAGE);
                        _loc2_.message = new WebSocketMessage();
                        _loc2_.message.type = WebSocketMessage.TYPE_UTF8;
                        _loc2_.message.utf8Data = param1.binaryPayload.readMultiByte(param1.length,"utf-8");
                        dispatchEvent(_loc2_);
                        break;
                     }
                     this.frameQueue.push(param1);
                     this.fragmentationOpcode = param1.opcode;
                     break;
                  }
                  this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Illegal TEXT_FRAME received in the middle of a fragmented message.  Expected a continuation or control frame.");
                  return;
               }
               break;
            case WebSocketOpcode.CONTINUATION:
               if(this.config.assembleFragments)
               {
                  if(this.fragmentationOpcode === WebSocketOpcode.CONTINUATION && param1.opcode === WebSocketOpcode.CONTINUATION)
                  {
                     this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Unexpected continuation frame.");
                     return;
                  }
                  this.fragmentationSize += param1.length;
                  if(this.fragmentationSize > this.config.maxMessageSize)
                  {
                     this.drop(WebSocketCloseStatus.MESSAGE_TOO_LARGE,"Maximum message size exceeded.");
                     return;
                  }
                  this.frameQueue.push(param1);
                  if(param1.fin)
                  {
                     _loc2_ = new WebSocketEvent(WebSocketEvent.MESSAGE);
                     _loc2_.message = new WebSocketMessage();
                     _loc7_ = this.frameQueue[0].opcode;
                     _loc8_ = new ByteArray();
                     _loc9_ = 0;
                     _loc3_ = 0;
                     while(_loc3_ < this.frameQueue.length)
                     {
                        _loc9_ += this.frameQueue[_loc3_].length;
                        _loc3_++;
                     }
                     if(_loc9_ > this.config.maxMessageSize)
                     {
                        this.drop(WebSocketCloseStatus.MESSAGE_TOO_LARGE,"Message size of " + _loc9_ + " bytes exceeds maximum accepted message size of " + this.config.maxMessageSize + " bytes.");
                        return;
                     }
                     _loc3_ = 0;
                     while(_loc3_ < this.frameQueue.length)
                     {
                        _loc4_ = this.frameQueue[_loc3_];
                        _loc8_.writeBytes(_loc4_.binaryPayload,0,_loc4_.binaryPayload.length);
                        _loc4_.binaryPayload.clear();
                        _loc3_++;
                     }
                     _loc8_.position = 0;
                     switch(_loc7_)
                     {
                        case WebSocketOpcode.BINARY_FRAME:
                           _loc2_.message.type = WebSocketMessage.TYPE_BINARY;
                           _loc2_.message.binaryData = _loc8_;
                           break;
                        case WebSocketOpcode.TEXT_FRAME:
                           _loc2_.message.type = WebSocketMessage.TYPE_UTF8;
                           _loc2_.message.utf8Data = _loc8_.readMultiByte(_loc8_.length,"utf-8");
                           break;
                        default:
                           this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Unexpected first opcode in fragmentation sequence: 0x" + _loc7_.toString(16));
                           return;
                     }
                     this.frameQueue = new Vector.<WebSocketFrame>();
                     this.fragmentationOpcode = 0;
                     this.fragmentationSize = 0;
                     dispatchEvent(_loc2_);
                  }
               }
               break;
            case WebSocketOpcode.PING:
               if(this.debug)
               {
                  logger("Received Ping");
               }
               _loc5_ = new WebSocketEvent(WebSocketEvent.PING,false,true);
               _loc5_.frame = param1;
               if(dispatchEvent(_loc5_))
               {
                  this.pong(param1.binaryPayload);
               }
               break;
            case WebSocketOpcode.PONG:
               if(this.debug)
               {
                  logger("Received Pong");
               }
               _loc6_ = new WebSocketEvent(WebSocketEvent.PONG);
               _loc6_.frame = param1;
               dispatchEvent(_loc6_);
               break;
            case WebSocketOpcode.CONNECTION_CLOSE:
               if(this.debug)
               {
                  logger("Received close frame");
               }
               if(this.waitingForServerClose)
               {
                  if(this.debug)
                  {
                     logger("Got close confirmation from server.");
                  }
                  this.closeTimer.stop();
                  this.waitingForServerClose = false;
                  this.socket.close();
                  break;
               }
               if(this.debug)
               {
                  logger("Sending close response to server.");
               }
               this.close(false);
               this.socket.close();
               break;
            default:
               if(this.debug)
               {
                  logger("Unrecognized Opcode: 0x" + param1.opcode.toString(16));
               }
               this.drop(WebSocketCloseStatus.PROTOCOL_ERROR,"Unrecognized Opcode: 0x" + param1.opcode.toString(16));
         }
      }
      
      private function handleSocketIOError(param1:IOErrorEvent) : void
      {
         if(this.debug)
         {
            logger("IO Error: " + param1);
         }
         dispatchEvent(param1);
         this.dispatchClosedEvent();
      }
      
      private function handleSocketSecurityError(param1:SecurityErrorEvent) : void
      {
         if(this.debug)
         {
            logger("Security Error: " + param1);
         }
         dispatchEvent(param1.clone());
         this.dispatchClosedEvent();
      }
      
      private function sendHandshake() : void
      {
         var _loc3_:String = null;
         this.serverHandshakeResponse = "";
         var _loc1_:String = this.host;
         if(this._secure && this._port !== 443 || !this._secure && this._port !== 80)
         {
            _loc1_ += ":" + this._port.toString();
         }
         var _loc2_:* = "";
         _loc2_ += "GET " + this.resource + " HTTP/1.1\r\n";
         _loc2_ += "Host: " + _loc1_ + "\r\n";
         _loc2_ += "Upgrade: websocket\r\n";
         _loc2_ += "Connection: Upgrade\r\n";
         _loc2_ += "Sec-WebSocket-Key: " + this.base64nonce + "\r\n";
         if(this._origin)
         {
            _loc2_ += "Origin: " + this._origin + "\r\n";
         }
         _loc2_ += "Sec-WebSocket-Version: 13\r\n";
         if(this._protocols)
         {
            _loc3_ = this._protocols.join(", ");
            _loc2_ += "Sec-WebSocket-Protocol: " + _loc3_ + "\r\n";
         }
         _loc2_ += "\r\n";
         if(this.debug)
         {
            logger(_loc2_);
         }
         this.socket.writeMultiByte(_loc2_,"us-ascii");
         this.handshakeTimer.stop();
         this.handshakeTimer.reset();
         this.handshakeTimer.start();
      }
      
      private function failHandshake(param1:String = "Unable to complete websocket handshake.") : void
      {
         if(this.debug)
         {
            logger(param1);
         }
         this._readyState = WebSocketState.CLOSED;
         if(this.socket.connected)
         {
            this.socket.close();
         }
         this.handshakeTimer.stop();
         this.handshakeTimer.reset();
         var _loc2_:WebSocketErrorEvent = new WebSocketErrorEvent(WebSocketErrorEvent.CONNECTION_FAIL);
         _loc2_.text = param1;
         dispatchEvent(_loc2_);
         var _loc3_:WebSocketEvent = new WebSocketEvent(WebSocketEvent.CLOSED);
         dispatchEvent(_loc3_);
      }
      
      private function failConnection(param1:String) : void
      {
         this._readyState = WebSocketState.CLOSED;
         if(this.socket.connected)
         {
            this.socket.close();
         }
         var _loc2_:WebSocketErrorEvent = new WebSocketErrorEvent(WebSocketErrorEvent.CONNECTION_FAIL);
         _loc2_.text = param1;
         dispatchEvent(_loc2_);
         var _loc3_:WebSocketEvent = new WebSocketEvent(WebSocketEvent.CLOSED);
         dispatchEvent(_loc3_);
      }
      
      private function drop(param1:uint = 1002, param2:String = null) : void
      {
         var _loc4_:WebSocketErrorEvent = null;
         if(!this.connected)
         {
            return;
         }
         this.fatalError = true;
         var _loc3_:String = "WebSocket: Dropping Connection. Code: " + param1.toString(10);
         if(param2)
         {
            _loc3_ += " - " + param2;
         }
         logger(_loc3_);
         this.frameQueue = new Vector.<WebSocketFrame>();
         this.fragmentationSize = 0;
         if(param1 !== WebSocketCloseStatus.NORMAL)
         {
            _loc4_ = new WebSocketErrorEvent(WebSocketErrorEvent.ABNORMAL_CLOSE);
            _loc4_.text = "Close reason: " + param1;
            dispatchEvent(_loc4_);
         }
         this.sendCloseFrame(param1,param2,true);
         this.dispatchClosedEvent();
         this.socket.close();
      }
      
      private function sendCloseFrame(param1:uint = 1000, param2:String = null, param3:Boolean = false) : void
      {
         var _loc4_:WebSocketFrame = new WebSocketFrame();
         _loc4_.fin = true;
         _loc4_.opcode = WebSocketOpcode.CONNECTION_CLOSE;
         _loc4_.closeStatus = param1;
         if(param2)
         {
            _loc4_.binaryPayload = new ByteArray();
            _loc4_.binaryPayload.writeUTFBytes(param2);
         }
         this.sendFrame(_loc4_,param3);
      }
      
      private function readServerHandshake() : void
      {
         var lines:Array;
         var responseLineMatch:Array;
         var httpVersion:String;
         var statusCode:int;
         var statusDescription:String;
         var responseLine:String = null;
         var header:Object = null;
         var lcName:String = null;
         var lcValue:String = null;
         var extensionsThisLine:Array = null;
         var byteArray:ByteArray = null;
         var expectedKey:String = null;
         var protocol:String = null;
         var upgradeHeader:Boolean = false;
         var connectionHeader:Boolean = false;
         var serverProtocolHeaderMatch:Boolean = false;
         var keyValidated:Boolean = false;
         var headersTerminatorIndex:int = -1;
         while(headersTerminatorIndex === -1 && this.readHandshakeLine())
         {
            if(this.handshakeBytesReceived > MAX_HANDSHAKE_BYTES)
            {
               this.failHandshake("Received more than " + MAX_HANDSHAKE_BYTES + " bytes during handshake.");
               return;
            }
            headersTerminatorIndex = int(this.serverHandshakeResponse.search(/\r?\n\r?\n/));
         }
         if(headersTerminatorIndex === -1)
         {
            return;
         }
         if(this.debug)
         {
            logger("Server Response Headers:\n" + this.serverHandshakeResponse);
         }
         this.serverHandshakeResponse = this.serverHandshakeResponse.slice(0,headersTerminatorIndex);
         lines = this.serverHandshakeResponse.split(/\r?\n/);
         responseLine = lines.shift();
         responseLineMatch = responseLine.match(/^(HTTP\/\d\.\d) (\d{3}) ?(.*)$/i);
         if(responseLineMatch.length === 0)
         {
            this.failHandshake("Unable to find correctly-formed HTTP status line.");
            return;
         }
         httpVersion = responseLineMatch[1];
         statusCode = parseInt(responseLineMatch[2],10);
         statusDescription = responseLineMatch[3];
         if(this.debug)
         {
            logger("HTTP Status Received: " + statusCode + " " + statusDescription);
         }
         if(statusCode !== 101)
         {
            this.failHandshake("An HTTP response code other than 101 was received.  Actual Response Code: " + statusCode + " " + statusDescription);
            return;
         }
         this.serverExtensions = [];
         try
         {
            while(lines.length > 0)
            {
               responseLine = lines.shift();
               header = this.parseHTTPHeader(responseLine);
               lcName = header.name.toLocaleLowerCase();
               lcValue = header.value.toLocaleLowerCase();
               if(lcName === "upgrade" && lcValue === "websocket")
               {
                  upgradeHeader = true;
               }
               else if(lcName === "connection" && lcValue === "upgrade")
               {
                  connectionHeader = true;
               }
               else if(lcName === "sec-websocket-extensions" && Boolean(header.value))
               {
                  extensionsThisLine = header.value.split(",");
                  this.serverExtensions = this.serverExtensions.concat(extensionsThisLine);
               }
               else if(lcName === "sec-websocket-accept")
               {
                  byteArray = new ByteArray();
                  byteArray.writeUTFBytes(this.base64nonce + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
                  expectedKey = Base64.encodeByteArray(new SHA1().hash(byteArray));
                  if(this.debug)
                  {
                     logger("Expected Sec-WebSocket-Accept value: " + expectedKey);
                  }
                  if(header.value === expectedKey)
                  {
                     keyValidated = true;
                  }
               }
               else if(lcName === "sec-websocket-protocol")
               {
                  if(this._protocols)
                  {
                     for each(protocol in this._protocols)
                     {
                        if(protocol == header.value)
                        {
                           this._serverProtocol = protocol;
                        }
                     }
                  }
               }
            }
         }
         catch(e:Error)
         {
            failHandshake("There was an error while parsing the following HTTP Header line:\n" + responseLine);
            return;
         }
         if(!upgradeHeader)
         {
            this.failHandshake("The server response did not include a valid Upgrade: websocket header.");
            return;
         }
         if(!connectionHeader)
         {
            this.failHandshake("The server response did not include a valid Connection: upgrade header.");
            return;
         }
         if(!keyValidated)
         {
            this.failHandshake("Unable to validate server response for Sec-Websocket-Accept header.");
            return;
         }
         if(Boolean(this._protocols) && !this._serverProtocol)
         {
            this.failHandshake("The server can not respond in any of our requested protocols");
            return;
         }
         if(this.debug)
         {
            logger("Server Extensions: " + this.serverExtensions.join(" | "));
         }
         this.handshakeTimer.stop();
         this.handshakeTimer.reset();
         this.serverHandshakeResponse = null;
         this._readyState = WebSocketState.OPEN;
         this.currentFrame = new WebSocketFrame();
         this.frameQueue = new Vector.<WebSocketFrame>();
         dispatchEvent(new WebSocketEvent(WebSocketEvent.OPEN));
         this.handleSocketData();
      }
      
      private function handleHandshakeTimer(param1:TimerEvent) : void
      {
         this.failHandshake("Timed out waiting for server response.");
      }
      
      private function parseHTTPHeader(param1:String) : Object
      {
         var _loc2_:Array = param1.split(/\: +/);
         return _loc2_.length === 2 ? {
            "name":_loc2_[0],
            "value":_loc2_[1]
         } : null;
      }
      
      private function readHandshakeLine() : Boolean
      {
         var _loc1_:String = null;
         while(this.socket.bytesAvailable)
         {
            _loc1_ = this.socket.readMultiByte(1,"us-ascii");
            ++this.handshakeBytesReceived;
            this.serverHandshakeResponse += _loc1_;
            if(_loc1_ == "\n")
            {
               return true;
            }
         }
         return false;
      }
      
      private function dispatchClosedEvent() : void
      {
         var _loc1_:WebSocketEvent = null;
         if(this.handshakeTimer.running)
         {
            this.handshakeTimer.stop();
         }
         if(this._readyState !== WebSocketState.CLOSED)
         {
            this._readyState = WebSocketState.CLOSED;
            _loc1_ = new WebSocketEvent(WebSocketEvent.CLOSED);
            dispatchEvent(_loc1_);
         }
      }
   }
}

