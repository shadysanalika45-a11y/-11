package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_uzun_duvar_3 extends MovieClip
   {
      
      public var christmas:MovieClip;
      
      public var snow:MovieClip;
      
      public function cadde_uzun_duvar_3()
      {
         super();
      }
   }
}

