package
{
   import flash.display.MovieClip;
   
   public dynamic class CdTabela2 extends MovieClip
   {
      
      public function CdTabela2()
      {
         super();
      }
   }
}

