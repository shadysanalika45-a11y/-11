package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_durak_tabela extends MovieClip
   {
      
      public function cadde_durak_tabela()
      {
         super();
      }
   }
}

