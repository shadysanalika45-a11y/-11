package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_park_masa_1 extends MovieClip
   {
      
      public function cadde_park_masa_1()
      {
         super();
      }
   }
}

