package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_sandal extends MovieClip
   {
      
      public function cadde_sandal()
      {
         super();
      }
   }
}

