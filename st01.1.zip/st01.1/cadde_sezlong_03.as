package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_sezlong_03 extends MovieClip
   {
      
      public function cadde_sezlong_03()
      {
         super();
      }
   }
}

