package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_bank1_5 extends MovieClip
   {
      
      public function cadde_bank1_5()
      {
         super();
      }
   }
}

