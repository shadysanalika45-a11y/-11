package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_girilmez_tabela_3 extends MovieClip
   {
      
      public function cadde_girilmez_tabela_3()
      {
         super();
      }
   }
}

