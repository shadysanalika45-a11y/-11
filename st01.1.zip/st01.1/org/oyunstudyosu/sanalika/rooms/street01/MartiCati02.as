package org.oyunstudyosu.sanalika.rooms.street01
{
   import flash.display.MovieClip;
   
   public dynamic class MartiCati02 extends MovieClip
   {
      
      public function MartiCati02()
      {
         super();
      }
   }
}

