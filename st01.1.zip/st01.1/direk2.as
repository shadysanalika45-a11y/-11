package
{
   import flash.display.MovieClip;
   
   public dynamic class direk2 extends MovieClip
   {
      
      public function direk2()
      {
         super();
      }
   }
}

