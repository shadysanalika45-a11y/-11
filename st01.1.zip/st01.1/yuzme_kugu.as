package
{
   import flash.display.MovieClip;
   
   public dynamic class yuzme_kugu extends MovieClip
   {
      
      public function yuzme_kugu()
      {
         super();
      }
   }
}

