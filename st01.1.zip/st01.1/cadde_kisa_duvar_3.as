package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_kisa_duvar_3 extends MovieClip
   {
      
      public var snow:MovieClip;
      
      public function cadde_kisa_duvar_3()
      {
         super();
      }
   }
}

