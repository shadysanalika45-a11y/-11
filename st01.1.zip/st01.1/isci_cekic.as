package
{
   import flash.display.MovieClip;
   
   public dynamic class isci_cekic extends MovieClip
   {
      
      public function isci_cekic()
      {
         super();
      }
   }
}

