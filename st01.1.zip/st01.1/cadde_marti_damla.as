package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_damla extends MovieClip
   {
      
      public function cadde_marti_damla()
      {
         super();
      }
   }
}

