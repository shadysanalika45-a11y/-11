package
{
   import flash.display.MovieClip;
   
   public dynamic class direk extends MovieClip
   {
      
      public var christmas:MovieClip;
      
      public function direk()
      {
         super();
      }
   }
}

