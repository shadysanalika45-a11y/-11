package
{
   import flash.display.MovieClip;
   
   public dynamic class sagdemir extends MovieClip
   {
      
      public function sagdemir()
      {
         super();
      }
   }
}

