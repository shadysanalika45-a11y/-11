package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_durak_arka_7 extends MovieClip
   {
      
      public function cadde_durak_arka_7()
      {
         super();
      }
   }
}

