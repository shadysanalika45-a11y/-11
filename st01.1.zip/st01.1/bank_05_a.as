package
{
   import flash.display.MovieClip;
   
   public dynamic class bank_05_a extends MovieClip
   {
      
      public function bank_05_a()
      {
         super();
      }
   }
}

