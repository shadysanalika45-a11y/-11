package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_3_golge extends MovieClip
   {
      
      public function cadde_marti_3_golge()
      {
         super();
      }
   }
}

