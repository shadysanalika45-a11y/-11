package
{
   import flash.display.MovieClip;
   
   public dynamic class CdTabela1 extends MovieClip
   {
      
      public function CdTabela1()
      {
         super();
      }
   }
}

