package
{
   import flash.display.MovieClip;
   
   public dynamic class CdTabela3 extends MovieClip
   {
      
      public function CdTabela3()
      {
         super();
      }
   }
}

