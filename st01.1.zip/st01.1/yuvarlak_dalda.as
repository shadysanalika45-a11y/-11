package
{
   import flash.display.MovieClip;
   
   public dynamic class yuvarlak_dalda extends MovieClip
   {
      
      public function yuvarlak_dalda()
      {
         super();
      }
   }
}

