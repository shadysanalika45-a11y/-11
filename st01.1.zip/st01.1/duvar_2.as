package
{
   import flash.display.MovieClip;
   
   public dynamic class duvar_2 extends MovieClip
   {
      
      public function duvar_2()
      {
         super();
      }
   }
}

