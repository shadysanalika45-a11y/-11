package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_park_koltuk_1 extends MovieClip
   {
      
      public function cadde_park_koltuk_1()
      {
         super();
      }
   }
}

