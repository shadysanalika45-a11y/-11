package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_sezlong_01 extends MovieClip
   {
      
      public function cadde_sezlong_01()
      {
         super();
      }
   }
}

