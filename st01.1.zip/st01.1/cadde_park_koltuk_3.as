package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_park_koltuk_3 extends MovieClip
   {
      
      public function cadde_park_koltuk_3()
      {
         super();
      }
   }
}

