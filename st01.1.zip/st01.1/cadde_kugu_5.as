package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_kugu_5 extends MovieClip
   {
      
      public function cadde_kugu_5()
      {
         super();
      }
   }
}

