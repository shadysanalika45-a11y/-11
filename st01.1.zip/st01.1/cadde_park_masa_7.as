package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_park_masa_7 extends MovieClip
   {
      
      public function cadde_park_masa_7()
      {
         super();
      }
   }
}

