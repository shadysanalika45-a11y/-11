package
{
   import flash.display.MovieClip;
   
   public dynamic class isci_cekicb extends MovieClip
   {
      
      public function isci_cekicb()
      {
         super();
      }
   }
}

