package
{
   import flash.display.MovieClip;
   
   public dynamic class snow extends MovieClip
   {
      
      public function snow()
      {
         super();
      }
   }
}

