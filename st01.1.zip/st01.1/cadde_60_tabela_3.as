package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_60_tabela_3 extends MovieClip
   {
      
      public function cadde_60_tabela_3()
      {
         super();
      }
   }
}

