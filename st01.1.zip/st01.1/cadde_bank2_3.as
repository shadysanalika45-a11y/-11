package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_bank2_3 extends MovieClip
   {
      
      public function cadde_bank2_3()
      {
         super();
      }
   }
}

