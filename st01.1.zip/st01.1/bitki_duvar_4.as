package
{
   import flash.display.MovieClip;
   
   public dynamic class bitki_duvar_4 extends MovieClip
   {
      
      public function bitki_duvar_4()
      {
         super();
      }
   }
}

