package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_kugu_3 extends MovieClip
   {
      
      public function cadde_kugu_3()
      {
         super();
      }
   }
}

