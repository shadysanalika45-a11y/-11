package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_durak_arka_3 extends MovieClip
   {
      
      public function cadde_durak_arka_3()
      {
         super();
      }
   }
}

