package
{
   import flash.display.MovieClip;
   
   public dynamic class koltukMask1 extends MovieClip
   {
      
      public function koltukMask1()
      {
         super();
      }
   }
}

