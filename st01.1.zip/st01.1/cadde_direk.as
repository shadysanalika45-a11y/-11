package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_direk extends MovieClip
   {
      
      public function cadde_direk()
      {
         super();
      }
   }
}

