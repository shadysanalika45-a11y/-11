package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_bank_3 extends MovieClip
   {
      
      public function cadde_bank_3()
      {
         super();
      }
   }
}

