package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_duz_ucan_5 extends MovieClip
   {
      
      public function cadde_marti_duz_ucan_5()
      {
         super();
      }
   }
}

