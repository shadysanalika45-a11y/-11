package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_sezlong_02 extends MovieClip
   {
      
      public function cadde_sezlong_02()
      {
         super();
      }
   }
}

