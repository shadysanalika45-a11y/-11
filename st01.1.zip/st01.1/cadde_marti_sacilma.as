package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_sacilma extends MovieClip
   {
      
      public function cadde_marti_sacilma()
      {
         super();
      }
   }
}

