package
{
   import flash.display.MovieClip;
   
   public dynamic class duvar_4 extends MovieClip
   {
      
      public function duvar_4()
      {
         super();
      }
   }
}

