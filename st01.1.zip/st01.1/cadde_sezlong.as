package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_sezlong extends MovieClip
   {
      
      public function cadde_sezlong()
      {
         super();
      }
   }
}

