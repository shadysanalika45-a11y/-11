package
{
   import flash.display.MovieClip;
   
   public dynamic class agac_2 extends MovieClip
   {
      
      public function agac_2()
      {
         super();
      }
   }
}

