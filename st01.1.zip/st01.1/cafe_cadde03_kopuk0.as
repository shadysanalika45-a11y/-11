package
{
   import flash.display.MovieClip;
   
   public dynamic class cafe_cadde03_kopuk0 extends MovieClip
   {
      
      public function cafe_cadde03_kopuk0()
      {
         super();
      }
   }
}

