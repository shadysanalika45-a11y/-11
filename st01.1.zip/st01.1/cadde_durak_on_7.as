package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_durak_on_7 extends MovieClip
   {
      
      public function cadde_durak_on_7()
      {
         super();
      }
   }
}

