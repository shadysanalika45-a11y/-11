package panel_fla
{
   import flash.display.MovieClip;
   
   public dynamic class mcSign_25 extends MovieClip
   {
      
      public function mcSign_25()
      {
         super();
      }
   }
}

