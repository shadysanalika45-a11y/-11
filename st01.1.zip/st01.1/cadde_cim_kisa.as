package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_cim_kisa extends MovieClip
   {
      
      public function cadde_cim_kisa()
      {
         super();
      }
   }
}

