package
{
   import flash.display.MovieClip;
   
   public dynamic class havuz_kenar extends MovieClip
   {
      
      public function havuz_kenar()
      {
         super();
      }
   }
}

