package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_yuruyen_5 extends MovieClip
   {
      
      public function cadde_marti_yuruyen_5()
      {
         super();
      }
   }
}

