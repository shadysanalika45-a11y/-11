package
{
   import flash.display.MovieClip;
   
   public dynamic class koltukMask7 extends MovieClip
   {
      
      public function koltukMask7()
      {
         super();
      }
   }
}

