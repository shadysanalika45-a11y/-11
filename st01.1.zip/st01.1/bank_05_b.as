package
{
   import flash.display.MovieClip;
   
   public dynamic class bank_05_b extends MovieClip
   {
      
      public function bank_05_b()
      {
         super();
      }
   }
}

