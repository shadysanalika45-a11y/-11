package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_marti_3 extends MovieClip
   {
      
      public function cadde_marti_3()
      {
         super();
      }
   }
}

