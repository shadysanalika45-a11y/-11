package
{
   import flash.display.MovieClip;
   
   public dynamic class bitki_duvar_1 extends MovieClip
   {
      
      public function bitki_duvar_1()
      {
         super();
      }
   }
}

