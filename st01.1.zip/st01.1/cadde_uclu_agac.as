package
{
   import flash.display.MovieClip;
   
   public dynamic class cadde_uclu_agac extends MovieClip
   {
      
      public function cadde_uclu_agac()
      {
         super();
      }
   }
}

